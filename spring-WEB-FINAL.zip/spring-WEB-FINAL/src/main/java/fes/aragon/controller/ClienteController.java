package fes.aragon.controller;

import fes.aragon.model.Persona;
import fes.aragon.service.PersonaService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "datos")
@SessionAttributes("lista")
public class ClienteController
{

    @Autowired
    private PersonaService personaService;

    @GetMapping("uno")
    public String uno(Model model)
    {
        var persona = personaService;
        model.addAttribute("persona", persona);
        return "paginas/Barra/PaginaUno";
    }

    @PostMapping("/informacion")
    public String infromacion(Persona persona)
    {
        personaService.save(persona);
        return "plantillas/Datos/Formulario";
    }

    @GetMapping("registro")
    public String registro()
    {
        return "plantillas/Datos/Formulario";
    }

    @GetMapping("dos")
    public String dos(Model model)
    {
        var persona = personaService;
        model.addAttribute("persona", persona);
        return "paginas/Barra/PaginaDos";
    }

    @GetMapping("almacenar")
    public String datosPersona(Model model)
    {
        System.out.println("Almacenar en la BD");
        var persona = personaService.findAll();
        model.addAttribute("persona", persona);
        return "redirect:/paginas/Barra/PaginaDos";
    }

}
