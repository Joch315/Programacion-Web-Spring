package fes.aragon.controller;

import fes.aragon.model.Persona;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
public class InicioController {

    @GetMapping("/")
    public String salto(){
        return "salto";
    }


    // NAVEGACION ATRAVES DE LA BARRRA

    @GetMapping("/principal")
    public String menu(){
        return "paginas/Barra/principal";
    }

    @GetMapping("/nosotros")
    public String nosotros()
    {
        return "paginas/Barra/Nosotros";
    }

    // NAVEGACION ATRAVES DE LA BARRRA

}
