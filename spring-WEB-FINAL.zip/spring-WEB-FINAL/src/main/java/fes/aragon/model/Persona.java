package fes.aragon.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.NumberFormat;

import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Entity
@Table(name = "personas")
public class Persona implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPersona;

    @NotEmpty
    private String password;


    @NotEmpty(message = "Nombre no debe ser vacío")
    //@Size(min = 3,max = 5,message = "Mínimo 3 y Máximo 5")
    private String nombre;

    @NotEmpty(message = "Apellido no debe ser vacio")
    private String apellido;
    @NotEmpty(message = "Correo no debe ser vacío")
    @Email(message = "Correo no valido")
    private String correo;

}
