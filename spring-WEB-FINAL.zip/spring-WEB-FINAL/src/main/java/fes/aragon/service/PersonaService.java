package fes.aragon.service;

import fes.aragon.model.Persona;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PersonaService extends CrudRepository<Persona,Long> {
    /*
    void agregarPersona(Persona persona);
    List<Persona> getLista();
    void setLista(List<Persona> lista);

     */

}
